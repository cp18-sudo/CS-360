package com.example.weighttracker;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.ViewHolder> {

    public interface OnDeleteListener {
        void onDelete(WeightEntry entry);
    }

    private final List<WeightEntry> entries;
    private final OnDeleteListener deleteListener;

    public WeightAdapter(List<WeightEntry> entries, OnDeleteListener deleteListener) {
        this.entries = entries;
        this.deleteListener = deleteListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_weight_entry, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        WeightEntry entry = entries.get(position);
        holder.dateText.setText(entry.getDate());
        holder.weightText.setText(String.valueOf(entry.getWeight()));
        holder.deleteButton.setOnClickListener(v -> {
            WeightEntry removed = entries.get(position);
            entries.remove(position);
            notifyItemRemoved(position);
            if (deleteListener != null) {
                deleteListener.onDelete(removed);
            }
        });
    }

    @Override
    public int getItemCount() {
        return entries.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView dateText, weightText;
        Button deleteButton;

        ViewHolder(View itemView) {
            super(itemView);
            dateText = itemView.findViewById(R.id.dateText);
            weightText = itemView.findViewById(R.id.weightText);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }
}