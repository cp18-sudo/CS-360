package com.example.weighttracker;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class DataGridActivity extends AppCompatActivity {

    private WeightAdapter adapter;
    private List<WeightEntry> weightEntries;
    private AppDatabase db;

    @SuppressLint("NotifyDataSetChanged")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_grid);

        RecyclerView weightRecyclerView = findViewById(R.id.weightRecyclerView);
        Button addEntryButton = findViewById(R.id.addEntryButton);
        Button smsPermissionButton = findViewById(R.id.smsPermissionButton);

        db = AppDatabase.getDatabase(this);
        weightEntries = new ArrayList<>();

        adapter = new WeightAdapter(weightEntries, entry -> DbExecutors.io().execute(() -> db.weightDao().deleteWeight(entry)));
        weightRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        weightRecyclerView.setAdapter(adapter);

        DbExecutors.io().execute(() -> {
            List<WeightEntry> entriesFromDb = db.weightDao().getAllWeights();
            runOnUiThread(() -> {
                weightEntries.clear();
                weightEntries.addAll(entriesFromDb);
                adapter.notifyDataSetChanged();
            });
        });

        addEntryButton.setOnClickListener(v -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle(getString(R.string.add_weight_title));

            final EditText input = new EditText(this);
            input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
            builder.setView(input);

            builder.setPositiveButton(getString(R.string.save), (dialog, which) -> {
                String weightText = input.getText().toString();
                if (!weightText.isEmpty()) {
                    double weight = Double.parseDouble(weightText);
                    String date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
                    WeightEntry newEntry = new WeightEntry(date, weight);
                    DbExecutors.io().execute(() -> {
                        db.weightDao().insertWeight(newEntry);
                        List<WeightEntry> updated = db.weightDao().getAllWeights();

                        double goalWeight = 150.0; // TODO: externalize user goal persistence
                        if (weight == goalWeight && ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                            runOnUiThread(() -> Toast.makeText(this, getString(R.string.weight_goal_reached), Toast.LENGTH_LONG).show());
                        }

                        runOnUiThread(() -> {
                            weightEntries.clear();
                            weightEntries.addAll(updated);
                            adapter.notifyDataSetChanged();
                        });
                    });
                }
            });

            builder.setNegativeButton(getString(R.string.cancel), (dialog, which) -> dialog.cancel());
            builder.show();
        });

        smsPermissionButton.setOnClickListener(v -> {
            Intent intent = new Intent(DataGridActivity.this, SmsPermissionActivity.class);
            startActivity(intent);
        });
    }
}