package com.example.weighttracker;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "weights")
public class WeightEntry {
    @PrimaryKey(autoGenerate = true)
    private int id = 0;

    private final String date;
    private final double weight;

    public WeightEntry(String date, double weight) {
        this.date = date;
        this.weight = weight;
    }

    public String getDate() { return date; }
    public double getWeight() { return weight; }

    public int getId() {
        return id;
    }
}