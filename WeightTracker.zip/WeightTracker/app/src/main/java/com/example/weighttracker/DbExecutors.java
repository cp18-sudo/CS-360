package com.example.weighttracker;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class DbExecutors {
    private static final ExecutorService IO = Executors.newSingleThreadExecutor();
    private DbExecutors() {}
    public static ExecutorService io() { return IO; }
}

